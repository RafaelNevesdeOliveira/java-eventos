#!/bin/bash
# Jornada B3: executar como usuario normal, sem sudo na frente deste script.
set -euo pipefail
destination="$HOME/JornadaB3/laboratorios-eda"
with_ide=1
while [ "$#" -gt 0 ]; do
  case "$1" in
    --plano)
      echo 'PLANO: instalar apenas ferramentas ausentes; Git, Python, Podman, Podman Desktop e VS Code (opcional).'
      echo 'Usar Homebrew para Git/Python/aplicativos e instalador oficial Podman 5.8.1 se o motor faltar.'
      echo 'Depois: reutilizar VM, preparar Compose, clonar aula-1, iniciar servicos e executar smoke.'
      echo 'Nenhuma instalacao ou alteracao foi executada.'
      exit 0 ;;
    --destino) [ "$#" -ge 2 ] || { echo 'Falta o caminho depois de --destino.' >&2; exit 1; }; destination="$2"; shift 2 ;;
    --sem-ide) with_ide=0; shift ;;
    *) echo "Opcao desconhecida: $1" >&2; exit 1 ;;
  esac
done
[ "$(uname -s)" = Darwin ] || { echo 'Use este arquivo somente no macOS.' >&2; exit 1; }
[ "$EUID" -ne 0 ] || { echo 'Execute sem sudo. O instalador pedira elevacao somente se precisar.' >&2; exit 1; }
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
[ -f "$script_dir/preparar-projeto.py" ] || { echo 'Extraia o ZIP completo: falta preparar-projeto.py.' >&2; exit 1; }
export PATH="/opt/podman/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
export HOMEBREW_NO_AUTO_UPDATE=1

find_python() {
  local candidate
  for candidate in python3 python3.14 python3.13 python3.12; do
    if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)' >/dev/null 2>&1; then
      python_bin="$(command -v "$candidate")"; return 0
    fi
  done
  return 1
}
ensure_brew() {
  if ! command -v brew >/dev/null 2>&1; then
    echo 'Instalando Homebrew pelo instalador oficial. Leia e confirme as solicitacoes na tela.'
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  fi
  if [ -x /opt/homebrew/bin/brew ]; then brew_bin=/opt/homebrew/bin/brew; else brew_bin=/usr/local/bin/brew; fi
  eval "$("$brew_bin" shellenv)"
  # Acrescenta somente a inicializacao do Homebrew, sem reescrever o perfil.
  profile="$HOME/.zprofile"
  case "${SHELL:-}" in */bash) profile="$HOME/.bash_profile" ;; esac
  line="eval \"\$($brew_bin shellenv)\""
  if ! grep -Fq "$line" "$profile" 2>/dev/null; then printf '\n%s\n' "$line" >> "$profile"; fi
}

if ! command -v git >/dev/null 2>&1 || ! xcode-select -p >/dev/null 2>&1; then
  ensure_brew
  brew install git
fi
if ! find_python; then
  ensure_brew
  brew install python
  hash -r
  find_python || { echo 'Python 3.10+ nao encontrado. Reabra o Terminal e execute novamente.' >&2; exit 1; }
fi
if ! command -v podman >/dev/null 2>&1; then
  echo 'Instalando o Podman oficial 5.8.1 para Intel e Apple Silicon.'
  setup_tmp="$(mktemp -d "${TMPDIR:-/tmp}/jornada-b3.XXXXXX")"
  trap 'rm -rf "$setup_tmp"' EXIT
  pkg="$setup_tmp/podman.pkg"
  curl --fail --location --retry 2 --output "$pkg" https://github.com/podman-container-tools/podman/releases/download/v5.8.1/podman-installer-macos-universal.pkg
  printf '%s  %s\n' b1984e573f30642efee9a35faf68097bb7d56b67ae8b38c0bfa0417916d7ccb3 "$pkg" | shasum -a 256 -c -
  sudo /usr/sbin/installer -pkg "$pkg" -target /
  hash -r
fi
if [ ! -d '/Applications/Podman Desktop.app' ] && [ ! -d "$HOME/Applications/Podman Desktop.app" ]; then
  ensure_brew
  brew install --cask podman-desktop
fi
if [ "$with_ide" -eq 1 ] && [ ! -d '/Applications/Visual Studio Code.app' ] && [ ! -d "$HOME/Applications/Visual Studio Code.app" ]; then
  ensure_brew
  brew install --cask visual-studio-code
fi
command -v podman >/dev/null 2>&1 || { echo 'Podman nao encontrado. Reabra o Terminal e execute novamente.' >&2; exit 1; }
"$python_bin" "$script_dir/preparar-projeto.py" --destino "$destination"
