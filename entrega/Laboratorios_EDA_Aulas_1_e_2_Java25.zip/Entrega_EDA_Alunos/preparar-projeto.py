#!/usr/bin/env python3
"""Finaliza o ambiente local da Jornada B3 depois da instalacao das ferramentas."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
from urllib.request import urlopen

COMPOSE = {
    ('Darwin', 'arm64'): ('docker-compose-darwin-aarch64', '83c6527089f438599f82e9ea97f60af206d241159df8c12a408f4a459d9ddae3'),
    ('Darwin', 'x86_64'): ('docker-compose-darwin-x86_64', 'c4affd2981e5a91c34076f8e1231be79f9c96d82397874db5a4f72a5398585c0'),
    ('Windows', 'amd64'): ('docker-compose-windows-x86_64.exe', '2e5ae01bbec3bd6ed3a5a267df7edee3c8c5fc59101a0aad0241ed4ed46c70ac'),
    # Windows 11 em ARM permite executar aplicativos x64 por emulacao.
    ('Windows', 'arm64'): ('docker-compose-windows-x86_64.exe', '2e5ae01bbec3bd6ed3a5a267df7edee3c8c5fc59101a0aad0241ed4ed46c70ac'),
}
REPOSITORY = 'https://github.com/RafaelNevesdeOliveira/java-eventos.git'

def run(args, *, cwd=None, capture=False, check=True, timeout=None):
    result = subprocess.run([str(arg) for arg in args], cwd=cwd, env=os.environ,
                            capture_output=capture, text=True, encoding='utf-8',
                            errors='replace', timeout=timeout)
    if check and result.returncode:
        raise RuntimeError('Falhou: ' + ' '.join(map(str, args)) +
                           ('\n' + result.stderr.strip() if capture else ''))
    return result

def environment_ready():
    for command in ['git', 'podman']:
        if not shutil.which(command):
            raise RuntimeError(command + ' nao encontrado. Reabra o terminal e execute o preparador novamente.')
    result = run(['podman', 'info', '--format', 'json'], capture=True, check=False, timeout=30)
    if result.returncode:
        machines = json.loads(run(['podman', 'machine', 'list', '--format', 'json'], capture=True).stdout)
        if not machines:
            command = ['podman', 'machine', 'init']
            if platform.system() == 'Darwin':
                command += ['--memory', '4096', '--cpus', str(min(os.cpu_count() or 1, 4))]
            run(command)
            machines = json.loads(run(['podman', 'machine', 'list', '--format', 'json'], capture=True).stdout)
        if len(machines) != 1:
            raise RuntimeError('Ha mais de uma VM. Selecione e inicie a VM correta no Podman Desktop e execute novamente.')
        machine = machines[0]
        name = machine.get('Name') or machine.get('name')
        if not name:
            raise RuntimeError('Nao foi possivel identificar a VM existente.')
        if machine.get('Running', machine.get('running', False)):
            raise RuntimeError('A VM esta ativa, mas a conexao falhou. Confira podman system connection list, sem recriar a VM.')
        run(['podman', 'machine', 'start', name])
        result = run(['podman', 'info', '--format', 'json'], capture=True, timeout=30)
    data = json.loads(result.stdout)
    memory = data.get('host', {}).get('memTotal', 0)
    minimum = 6 * 1024**3 if platform.system() == 'Windows' else 4 * 1024**3
    # A VM de 4 GiB reporta um pouco menos ao SO; nao confundir reserva com memoria util.
    if memory and memory < minimum * .9:
        print('ATENCAO: confira a RAM da VM no guia. Limites existentes e .wslconfig nao foram alterados.', flush=True)

def ensure_compose():
    current = run(['podman', 'compose', 'version'], capture=True, check=False, timeout=30)
    if current.returncode == 0:
        print(current.stdout.strip(), flush=True)
        return
    if os.environ.get('PODMAN_COMPOSE_PROVIDER'):
        raise RuntimeError('O provedor definido em PODMAN_COMPOSE_PROVIDER falhou. Revise essa variavel antes de continuar.')
    binary = shutil.which('docker-compose')
    if not binary:
        key = (platform.system(), platform.machine().lower())
        if key not in COMPOSE:
            raise RuntimeError('Instale Compose por Settings > Resources > Compose > Setup e execute novamente.')
        asset, checksum = COMPOSE[key]
        tools = Path.home() / 'JornadaB3' / 'ferramentas'
        tools.mkdir(parents=True, exist_ok=True)
        target = tools / ('docker-compose.exe' if platform.system() == 'Windows' else 'docker-compose')
        if target.exists():
            payload = target.read_bytes()
            if hashlib.sha256(payload).hexdigest() != checksum:
                raise RuntimeError('Ja existe outro arquivo em ' + str(target) + '. Ele foi preservado.')
        else:
            with urlopen('https://github.com/docker/compose/releases/download/v2.27.0/' + asset, timeout=60) as response:
                payload = response.read()
            if hashlib.sha256(payload).hexdigest() != checksum:
                raise RuntimeError('Hash do Compose incorreto; nenhum executavel foi instalado.')
            # Escrita exclusiva: nao substitui um arquivo criado por outro processo.
            with target.open('xb') as output:
                output.write(payload)
        if platform.system() != 'Windows':
            target.chmod(0o755)
        binary = str(target)
    os.environ['PODMAN_COMPOSE_PROVIDER'] = binary
    run(['podman', 'compose', 'version'])
    config_root = (Path(os.environ.get('APPDATA', str(Path.home() / 'AppData/Roaming'))) / 'containers'
                   if platform.system() == 'Windows'
                   else Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'containers')
    fragment = config_root / 'containers.conf.d' / '90-jornada-b3-compose.conf'
    content = '[engine]\ncompose_providers = [' + json.dumps(binary) + ']\n'
    if fragment.exists() and fragment.read_text(encoding='utf-8') != content:
        raise RuntimeError('Configuracao anterior preservada em ' + str(fragment) + '. Confira o provedor manualmente.')
    created = not fragment.exists()
    if created:
        fragment.parent.mkdir(parents=True, exist_ok=True)
        with fragment.open('x', encoding='utf-8') as output:
            output.write(content)
    # Confere a configuracao persistida, sem depender da variavel deste processo.
    del os.environ['PODMAN_COMPOSE_PROVIDER']
    try:
        run(['podman', 'compose', 'version'], timeout=30)
    except (RuntimeError, OSError, subprocess.TimeoutExpired):
        if created:
            fragment.unlink()
        raise RuntimeError('Compose nao foi reconhecido pela configuracao local. Use Compose > Setup no Podman Desktop.')
    finally:
        os.environ['PODMAN_COMPOSE_PROVIDER'] = binary
    print('Provedor Compose configurado em ' + str(fragment), flush=True)

def prepare_repository(destination):
    if destination.exists():
        top = run(['git', '-C', destination, 'rev-parse', '--show-toplevel'], capture=True, check=False)
        if top.returncode or Path(top.stdout.strip()).resolve() != destination.resolve():
            raise RuntimeError('Pasta existente preservada: ' + str(destination) + '. Escolha outro -Destino/--destino.')
        if run(['git', 'status', '--porcelain'], cwd=destination, capture=True).stdout.strip():
            raise RuntimeError('O projeto tem alteracoes locais. Salve-as antes de executar novamente. Nenhum arquivo foi alterado.')
        branch = run(['git', 'branch', '--show-current'], cwd=destination, capture=True).stdout.strip()
        if branch != 'aula-1':
            raise RuntimeError('Projeto existente na branch ' + branch + '. Selecione aula-1 manualmente ou escolha outro destino.')
    else:
        destination.parent.mkdir(parents=True, exist_ok=True)
        bundle = Path(__file__).resolve().parent / 'Laboratorios_EDA_Aulas_1_e_2.bundle'
        run(['git', 'clone', '-b', 'aula-1', str(bundle) if bundle.is_file() else REPOSITORY, destination])
    for relative in ['aula1/Dockerfile', 'ordens-domain/pom.xml', 'scripts/smoke.py', 'compose.yaml']:
        if not (destination / relative).is_file():
            raise RuntimeError('A pasta nao corresponde ao laboratorio esperado: falta ' + relative)

def guard_existing_project(destination):
    rows = json.loads(run(['podman', 'ps', '-a', '--filter',
                          'label=com.docker.compose.project=b3-eda-aulas12',
                          '--format', 'json'], capture=True).stdout)
    for row in rows:
        labels = row.get('Labels', {})
        previous = labels.get('com.docker.compose.project.working_dir') if isinstance(labels, dict) else None
        if previous and Path(previous).resolve() != destination.resolve():
            raise RuntimeError('Ha containers do laboratorio ligados a outra pasta: ' + previous +
                               '. Use esse caminho como destino ou encerre aquela execucao manualmente.')
        if not previous and row.get('State', '').lower() == 'running':
            raise RuntimeError('Ha um laboratorio ativo sem pasta identificavel. Confira-o antes de continuar.')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destino', type=Path, default=Path.home() / 'JornadaB3' / 'laboratorios-eda')
    parser.add_argument('--plano', action='store_true', help='Mostra as etapas sem executar comandos ou alterar arquivos')
    args = parser.parse_args()
    destination = args.destino.expanduser().resolve()
    if args.plano:
        print('PLANO: conferir/reutilizar VM; configurar Compose se faltar; clonar/reutilizar aula-1 em ' + str(destination) +
              '; iniciar aula1, RabbitMQ e Kafka; executar smoke. Sem reset, prune, alteracao de limites WSL ou exclusao de volumes.')
        return
    if sys.version_info < (3, 10):
        raise RuntimeError('Python 3.10 ou superior e necessario.')
    # Recusa um destino inadequado antes de iniciar a VM ou configurar o provedor.
    prepare_repository(destination)
    environment_ready()
    ensure_compose()
    guard_existing_project(destination)
    print('Preparando a aula 1 em ' + str(destination), flush=True)
    run(['podman', 'compose', 'config', '--quiet'], cwd=destination)
    run(['podman', 'compose', 'up', '-d', '--build', 'aula1'], cwd=destination)
    run([sys.executable, 'scripts/smoke.py', '--aula', '1'], cwd=destination)
    run(['podman', 'compose', 'ps'], cwd=destination)
    print('\nPRONTO: aula 1 verificada. Projeto: ' + str(destination) +
          '\nAPI: http://localhost:8080\nPara encerrar preservando dados, nessa pasta: podman compose down', flush=True)

if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError, subprocess.TimeoutExpired) as error:
        print('\nPREPARACAO INTERROMPIDA: ' + str(error) + '\nVM, volumes e alteracoes existentes foram preservados.', file=sys.stderr)
        sys.exit(1)
