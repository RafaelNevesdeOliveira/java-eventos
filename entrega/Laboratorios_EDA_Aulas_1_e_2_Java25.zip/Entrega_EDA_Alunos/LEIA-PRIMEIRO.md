# Laboratórios EDA — entrega para os alunos

Esta entrega de 21/10/2026 corresponde à versão final publicada no [GitHub da turma](https://github.com/RafaelNevesdeOliveira/java-eventos). O pacote inclui os guias revisados e um repositório Git clonável com as branches **aula-1** e **aula-2**. O arquivo `.bundle` contém os fontes e o histórico revisado das três branches; não é uma imagem de container.

Comece pela [mensagem de uma página](Mensagem_Alunos_Preparacao_Aula_1.docx): ela reúne o link do ZIP e os comandos de preparação automática para Windows e Mac.

## Já tinha baixado ou clonado antes

O histórico do Git foi revisado. Baixe o ZIP novo e faça um novo clone, seguindo a mensagem em Word incluída neste pacote.

1. Copie seus exercícios para uma pasta de backup fora do projeto antigo e mantenha essa cópia.
2. Se já executou o laboratório, no terminal do projeto antigo, use `podman compose --profile contratos down` para encerrar os containers sem apagar os volumes.
3. Feche a IDE e renomeie a pasta antiga para um nome disponível, como `laboratorios-eda-antigo`. Não apague essa pasta. Deixe livre o destino padrão `JornadaB3/laboratorios-eda` dentro da sua pasta pessoal.
4. Extraia o ZIP novo em uma pasta nova, abra `Entrega_EDA_Alunos` e execute o preparador do seu sistema abaixo. Ele fará um novo clone.
5. Ao aparecer **PRONTO**, abra o projeto novo e retome seus exercícios copiando apenas os arquivos necessários. Não copie `.git` nem substitua o projeto inteiro.

Não use `git pull` na cópia antiga nem mescle o histórico antigo nas branches de referência. Se ainda não tinha o projeto, siga diretamente a preparação automática.

## Preparação automática

Extraia o ZIP completo e abra o terminal na pasta `Entrega_EDA_Alunos`, mantendo os três scripts ao lado do bundle.

**Windows — PowerShell:**

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\preparar-windows.ps1
```

**macOS — Terminal:**

```sh
bash ./preparar-mac.sh
```

Os preparadores instalam ferramentas ausentes, reutilizam a VM existente ou criam uma se não houver, configuram Compose quando necessário, clonam a branch `aula-1`, iniciam os serviços e executam o smoke HTTP. O projeto fica por padrão em `JornadaB3/laboratorios-eda` dentro da pasta pessoal. Podem solicitar permissões; no Windows, se pedirem reinício, reinicie e repita o comando. Consulte o Word para pré-requisitos, opções e diagnóstico.

Ao terminar com **PRONTO**, abra o projeto no caminho informado e siga o guia da aula 1; não repita o clone manual abaixo. Para encerrar, execute `podman compose down` dentro do projeto. Os scripts preservam alterações locais, VMs e volumes; em caso de conflito, interrompem e explicam o motivo.

Foram conferidos a sintaxe, o modo de plano e cenários simulados de preservação. Não foi realizada instalação completa em Windows ou Mac limpo nesta revisão.

## Sequência manual de uso

1. Descompacte o ZIP em uma pasta local.
2. Abra o [guia de preparação para Windows e macOS](Guia_Preparacao_Ambiente_Windows_macOS_Jornada_B3.docx), em Word, e siga a seção do seu sistema. Confira também [a preparação do ambiente](docs/COMECE-AQUI.md) e valide Git, Podman e Compose.
3. Abra o terminal nesta pasta, ao lado do arquivo `.bundle`, e clone:

```sh
git clone -b aula-1 ./Laboratorios_EDA_Aulas_1_e_2.bundle laboratorios-eda
cd laboratorios-eda
```

4. Siga [o passo a passo da aula 1](docs/AULA-1.md). A cópia do guia também está em `laboratorios-eda/docs/` após o clone.
5. Encerre os containers, salve suas alterações na branch de exercício e troque com `git switch aula-2`.
6. Siga [o passo a passo da aula 2](docs/AULA-2.md).

Todos os comandos Compose/Maven e scripts do laboratório devem ser executados **dentro de `laboratorios-eda`**, não nesta pasta de entrega.

## O que cada branch contém

- `aula-1`: domínio e aplicação com RabbitMQ/Kafka; 11 testes Java na referência.
- `aula-2`: evolução com PostgreSQL, CloudEvents, Outbox, Inbox e projeção; 30 testes Java na raiz, ou 21 selecionando domínio + aula 2.
- `main`: núcleo inicial e preparação.

O clone pelo bundle funciona sem hospedagem Git. O primeiro build ainda precisa de internet para imagens e dependências. O roteiro principal compila e executa Java dentro dos containers.

O [mapa de arquitetura](docs/ARQUITETURA.md) mostra a posição dos casos de uso, portas, adaptadores e configuração. Cada guia acompanha os fluxos e oferece exercícios com resultados esperados.

## Maven e classes comentadas

O build usa Maven e Java 25. A organização é **controller**, **domain**, **infra** e **presenter**. Todos os arquivos Java têm comentários nas declarações de classes, records e interfaces. Leia [a arquitetura](docs/ARQUITETURA.md) e [a função de cada classe e quem chama quem](docs/CLASSES-E-FLUXOS.md).

Depois do clone, execute `mvn clean verify` na raiz, se tiver JDK 25 e Maven 3.9 no computador. O guia de arquitetura mostra como iniciar somente a infraestrutura no Podman e executar a API com `mvn spring-boot:run`. Os Dockerfiles também usam Maven e preservam a alternativa de execução inteira em containers.

## Verificação da entrega

O bundle foi conferido e clonado em uma pasta nova. Cada branch contém os mesmos arquivos da respectiva branch publicada no GitHub, com o histórico filtrado para remover os gabaritos e as orientações do professor de todos os commits. O histórico de desenvolvimento, os autores e as datas foram preservados. Os commits do bundle são os mesmos publicados no GitHub e estão no manifesto. Foram verificadas a transição `aula-1` → `aula-2`, a seleção de `main` e a igualdade dos guias externos com os arquivos da branch `aula-2`.

Na revisão da organização em quatro camadas, `mvn clean verify` passou com **2 testes em main**, **11 em aula-1** e **30 na raiz de aula-2**. Selecionar domínio + aula 2 executa **21 testes**. Os testes incluem regras do domínio, casos de uso, contratos HTTP/CloudEvents e ArchUnit.

As duas aplicações foram executadas com **Maven no computador**, e RabbitMQ, Kafka e PostgreSQL na VM **Podman 5.8.1 rootless de 4 GiB**, preservando os volumes existentes:

- Aula 1: HTTP 202/400, publicação confirmada e recebimento do evento por Risco e Auditoria.
- Aula 2: entrada inválida, rollback, pausa/retomada do relay, convergência e três reenvios sem duplicar a posição.

A VM foi encerrada normalmente ao final, com todos os volumes anteriores preservados. Não houve reset ou migração de tabelas. Os testes anteriores com Schema Registry, indisponibilidade/recuperação do Kafka e persistência após parada/partida continuam registrados; esses cenários não foram repetidos nesta revisão. Veja [VALIDACAO.md](docs/VALIDACAO.md).

O `manifesto.json` informa os commits e o SHA-256 do bundle e dos guias. A geração deste pacote verificou o empacotamento e o clone; os testes funcionais citados são os registrados no commit de referência. Backups da VM e arquivos locais de diagnóstico não fazem parte da entrega aos alunos.

O guia em Word também está disponível como anexo separado da release. Ele distingue os requisitos atuais do Windows com WSL 2 da execução validada no macOS; confira a orientação de memória correspondente ao seu sistema.

Após a reescrita do histórico, quem já tinha clonado o projeto deve salvar seus exercícios fora da pasta antiga e fazer um novo clone pelo bundle atualizado. Não mescle o histórico antigo nas branches de referência.
