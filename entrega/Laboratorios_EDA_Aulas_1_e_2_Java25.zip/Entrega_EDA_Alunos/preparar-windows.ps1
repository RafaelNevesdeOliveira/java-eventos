#Requires -Version 5.1
[CmdletBinding()]
param(
    [string]$Destino = (Join-Path $env:USERPROFILE 'JornadaB3\laboratorios-eda'),
    [switch]$SemIDE,
    [switch]$MostrarPlano
)
$ErrorActionPreference = 'Stop'
if ($MostrarPlano) {
    Write-Host 'PLANO: conferir WSL 2; instalar ferramentas ausentes por WinGet; Git, Python, Podman 5.8.1, Podman Desktop e VS Code opcional.'
    Write-Host 'Se o WSL exigir reinicio, interromper e repetir o mesmo comando depois de reiniciar.'
    Write-Host 'Depois: reutilizar VM, configurar Compose, clonar aula-1, iniciar servicos e executar smoke.'
    Write-Host 'Nenhuma instalacao ou alteracao foi executada.'
    exit 0
}
if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Execute este arquivo no Windows.' }
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'preparar-projeto.py'))) {
    throw 'Extraia o ZIP completo: falta preparar-projeto.py.'
}
$script:NeedRestart = $false
function Refresh-CommandPath {
    $paths = @([Environment]::GetEnvironmentVariable('Path', 'Machine'),
               [Environment]::GetEnvironmentVariable('Path', 'User'), $env:Path,
               (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links'),
               (Join-Path $env:ProgramFiles 'Git\cmd'),
               (Join-Path $env:ProgramFiles 'RedHat\Podman'),
               (Join-Path $env:ProgramFiles 'Podman'))
    $env:Path = ($paths | Where-Object { $_ }) -join ';'
}
function Require-Admin {
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Para preparar o WSL, abra PowerShell como administrador e repita o comando. Em maquina corporativa, solicite apoio da TI.'
    }
}
function Ensure-Package([string]$Id, [string]$Version = '') {
    & winget.exe list --id $Id --exact --source winget --accept-source-agreements | Out-Host
    if ($LASTEXITCODE -eq 0) { Refresh-CommandPath; return }
    $installArgs = @('install', '--id', $Id, '--exact', '--source', 'winget',
        '--silent', '--no-upgrade', '--accept-source-agreements', '--accept-package-agreements')
    if ($Version) { $installArgs += @('--version', $Version) }
    & winget.exe @installArgs | Out-Host
    $code = $LASTEXITCODE
    if ($code -in @(3010, 1641)) { $script:NeedRestart = $true }
    elseif ($code -ne 0) { throw "Instalacao de $Id falhou, codigo $code. Confira as mensagens do WinGet." }
    Refresh-CommandPath
}
function Find-Python {
    $candidates = @('py.exe', 'python.exe', 'python3.exe')
    foreach ($pattern in @((Join-Path $env:LOCALAPPDATA 'Programs\Python\Python*\python.exe'),
                           (Join-Path $env:ProgramFiles 'Python*\python.exe'))) {
        $candidates += @(Get-ChildItem -Path $pattern -File -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
    }
    foreach ($candidate in $candidates) {
        $command = Get-Command $candidate -ErrorAction SilentlyContinue
        if (-not $command) { continue }
        $prefix = @()
        if ($candidate -eq 'py.exe') { $prefix = @('-3') }
        $checkArgs = @($prefix) + @('-c', 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)')
        try {
            & $command.Source @checkArgs 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) { return @{ Executable = $command.Source; Prefix = $prefix } }
        } catch { continue }
    }
    return $null
}
try {
    Refresh-CommandPath
    if (-not (Get-Command winget.exe -ErrorAction SilentlyContinue)) {
        throw 'Instale ou atualize o App Installer da Microsoft para disponibilizar WinGet, reabra o PowerShell e repita.'
    }
    if (-not (Get-Command wsl.exe -ErrorAction SilentlyContinue)) {
        throw 'WSL nao encontrado. Confira os requisitos do Windows no guia com a TI.'
    }
    $boot = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().ToString('o')
    $stateDir = Join-Path $env:LOCALAPPDATA 'JornadaB3'
    $restartFile = Join-Path $stateDir 'wsl-reinicio.json'
    if (Test-Path -LiteralPath $restartFile) {
        $state = Get-Content -LiteralPath $restartFile -Raw | ConvertFrom-Json
        if ($state.boot -eq $boot) {
            Write-Host 'REINICIO NECESSARIO: reinicie o Windows e execute novamente este mesmo comando.'
            exit 3010
        }
        Remove-Item -LiteralPath $restartFile
    }
    $wslReady = $false
    try {
        & wsl.exe --version 2>&1 | Out-Host
        $wslReady = $LASTEXITCODE -eq 0
    } catch { $wslReady = $false }
    if (-not $wslReady) {
        Require-Admin
        & wsl.exe --install --no-distribution | Out-Host
        if ($LASTEXITCODE -notin @(0, 3010, 1641)) { throw 'Instalacao WSL falhou. Confira a virtualizacao e o guia com a TI.' }
        & wsl.exe --update | Out-Host
        if ($LASTEXITCODE -notin @(0, 3010, 1641)) { throw 'Atualizacao WSL falhou. Confira a mensagem com a TI.' }
        New-Item -ItemType Directory -Path $stateDir -Force | Out-Null
        @{ boot = $boot } | ConvertTo-Json | Set-Content -LiteralPath $restartFile -Encoding UTF8
        Write-Host 'REINICIO NECESSARIO: reinicie o Windows e repita o mesmo comando. Nenhuma distribuicao foi removida.'
        exit 3010
    }
    if (-not (Get-Command git.exe -ErrorAction SilentlyContinue)) { Ensure-Package 'Git.Git' }
    $python = Find-Python
    if (-not $python) { Ensure-Package 'Python.Python.3.14'; $python = Find-Python }
    if (-not (Get-Command podman.exe -ErrorAction SilentlyContinue)) { Ensure-Package 'RedHat.Podman' '5.8.1' }
    Ensure-Package 'RedHat.Podman-Desktop'
    if (-not $SemIDE) { Ensure-Package 'Microsoft.VisualStudioCode' }
    if ($script:NeedRestart) {
        Write-Host 'Um instalador pediu reinicio. Reinicie o Windows e repita o mesmo comando.'
        exit 3010
    }
    if (-not $python) { throw 'Python 3.10+ ainda nao foi encontrado. Reabra o PowerShell e repita.' }
    if (-not (Get-Command podman.exe -ErrorAction SilentlyContinue)) {
        throw 'Podman ainda nao foi encontrado. Reabra o PowerShell e repita.'
    }
    $projectArgs = @($python.Prefix) + @((Join-Path $PSScriptRoot 'preparar-projeto.py'), '--destino', $Destino)
    & $python.Executable @projectArgs
    if ($LASTEXITCODE -ne 0) { throw 'A configuracao do projeto foi interrompida. Leia a mensagem anterior.' }
} catch {
    Write-Error $_
    exit 1
}
